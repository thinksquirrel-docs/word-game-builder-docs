var searchData=
[
  ['pixel',['Pixel',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_tiles_1_1_letter_tile.html#a6a268b1d5c0193713fbe716a41272ef8a08822b3ae4e2aede0afe08abe600e9c0',1,'ThinksquirrelSoftware::WordGameBuilder::Tiles::LetterTile']]]
];
