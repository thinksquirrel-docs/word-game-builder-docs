var searchData=
[
  ['local',['Local',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_tiles_1_1_letter_tile.html#a6a268b1d5c0193713fbe716a41272ef8a509820290d57f333403f490dde7316f4',1,'ThinksquirrelSoftware::WordGameBuilder::Tiles::LetterTile']]]
];
