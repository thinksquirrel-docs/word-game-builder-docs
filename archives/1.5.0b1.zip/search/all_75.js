var searchData=
[
  ['uicontext',['UiContext',['../class_thinksquirrel_software_1_1_word_game_builder_example_1_1_example_view_model_1_1_ui_context.html',1,'ThinksquirrelSoftware::WordGameBuilderExample::ExampleViewModel']]],
  ['userdata',['userData',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_w_g_b_base.html#a60e040fc2de55749cb3510845ee15f62',1,'ThinksquirrelSoftware.WordGameBuilder.WGBBase.userData()'],['../interface_thinksquirrel_software_1_1_word_game_builder_1_1_object_model_1_1_i_mono_behaviour.html#a60e040fc2de55749cb3510845ee15f62',1,'ThinksquirrelSoftware.WordGameBuilder.ObjectModel.IMonoBehaviour.userData()']]]
];
