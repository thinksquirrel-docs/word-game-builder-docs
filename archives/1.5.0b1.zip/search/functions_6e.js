var searchData=
[
  ['nextletter',['NextLetter',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_language.html#a2a8c965b4e0492f472d966a7a880f5f5',1,'ThinksquirrelSoftware.WordGameBuilder.Language.NextLetter(Letter firstLetter)'],['../class_thinksquirrel_software_1_1_word_game_builder_1_1_language.html#ad27f78204a7ba87ef328ea3837fb53de',1,'ThinksquirrelSoftware.WordGameBuilder.Language.NextLetter(Letter firstLetter, bool wrap)']]]
];
