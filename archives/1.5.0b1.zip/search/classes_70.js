var searchData=
[
  ['playercontext',['PlayerContext',['../class_thinksquirrel_software_1_1_word_game_builder_example_1_1_example_view_model_1_1_player_context.html',1,'ThinksquirrelSoftware::WordGameBuilderExample::ExampleViewModel']]]
];
