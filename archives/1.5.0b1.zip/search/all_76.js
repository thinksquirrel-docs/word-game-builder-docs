var searchData=
[
  ['version',['version',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_version_info.html#af9c8593b58583463efe6932e24c9d6e6',1,'ThinksquirrelSoftware::WordGameBuilder::VersionInfo']]],
  ['versioninfo',['VersionInfo',['../class_thinksquirrel_software_1_1_word_game_builder_1_1_version_info.html',1,'ThinksquirrelSoftware::WordGameBuilder']]]
];
