var searchData=
[
  ['getting_20started_20guide',['Getting Started Guide',['../guide.html',1,'index']]]
];
