var searchData=
[
  ['advanced_20topics',['Advanced Topics',['../advanced.html',1,'index']]]
];
