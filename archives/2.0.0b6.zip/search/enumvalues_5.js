var searchData=
[
  ['nochange',['NoChange',['../class_thinksquirrel_1_1_word_game_builder_1_1_tiles_1_1_letter_tile.html#a536c265bad23c07b5807965aa94fa8cfa4bac8cdf0a968472b519b3b295d0d48b',1,'Thinksquirrel::WordGameBuilder::Tiles::LetterTile']]],
  ['none',['None',['../class_thinksquirrel_1_1_word_game_builder_1_1_tiles_1_1_letter_tile.html#a7059dfa0ed70c89facc3d317fb4138b3a6adf97f83acf6453d4a6a4b1070f3754',1,'Thinksquirrel::WordGameBuilder::Tiles::LetterTile']]]
];
