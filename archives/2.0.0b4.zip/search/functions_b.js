var searchData=
[
  ['previousletter',['PreviousLetter',['../class_thinksquirrel_1_1_word_game_builder_1_1_word_game_language.html#a66d0e2a5ec86b7bc5268698ca1cffe56',1,'Thinksquirrel.WordGameBuilder.WordGameLanguage.PreviousLetter(Letter firstLetter)'],['../class_thinksquirrel_1_1_word_game_builder_1_1_word_game_language.html#a6cf92a667deeefa4b8784eb122091651',1,'Thinksquirrel.WordGameBuilder.WordGameLanguage.PreviousLetter(Letter firstLetter, bool wrap)']]]
];
