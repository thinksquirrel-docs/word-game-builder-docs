var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuw",
  1: "acdegilpstuw",
  2: "t",
  3: "acdefgilmnoprstw",
  4: "k",
  5: "dels",
  6: "cdehlnpsuw",
  7: "abcdeghilmnoprstuw",
  8: "o",
  9: "clrtw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events",
  9: "Pages"
};

