var searchData=
[
  ['penalty',['penalty',['../class_thinksquirrel_1_1_word_game_builder_1_1_tiles_1_1_letter_tile_1_1_color_info.html#a4ae114786f7488b51b895e6f9b7cccb9',1,'Thinksquirrel::WordGameBuilder::Tiles::LetterTile::ColorInfo']]],
  ['permutationresult',['permutationResult',['../class_thinksquirrel_1_1_word_game_builder_example_1_1_example_view_model_1_1_player_context.html#aa775633266a4fce7076398d3260ef8e7',1,'Thinksquirrel::WordGameBuilderExample::ExampleViewModel::PlayerContext']]],
  ['player',['player',['../class_thinksquirrel_1_1_word_game_builder_example_1_1_example_view_model.html#a229d36cefc3fd78a495e4e308d60c1d7',1,'Thinksquirrel::WordGameBuilderExample::ExampleViewModel']]],
  ['playerid',['playerID',['../class_thinksquirrel_1_1_word_game_builder_1_1_gameplay_1_1_word_game_player.html#a1c62381f30093f5524035d3bef8bebe7',1,'Thinksquirrel::WordGameBuilder::Gameplay::WordGamePlayer']]],
  ['poolmultiplier',['poolMultiplier',['../class_thinksquirrel_1_1_word_game_builder_1_1_gameplay_1_1_tile_pool.html#a6a6949811dd67fe62ef4f7cde3e1ca15',1,'Thinksquirrel::WordGameBuilder::Gameplay::TilePool']]],
  ['previouswords',['previousWords',['../class_thinksquirrel_1_1_word_game_builder_1_1_gameplay_1_1_word_game_player.html#a19c4fd80fc74530aece72c5fae26ed9c',1,'Thinksquirrel::WordGameBuilder::Gameplay::WordGamePlayer']]],
  ['previouswordscapacity',['previousWordsCapacity',['../class_thinksquirrel_1_1_word_game_builder_1_1_gameplay_1_1_word_game_player.html#a26a9e5ba3deb662fae02ff06d61d1148',1,'Thinksquirrel::WordGameBuilder::Gameplay::WordGamePlayer']]],
  ['processwildcards',['processWildcards',['../class_thinksquirrel_1_1_word_game_builder_1_1_gameplay_1_1_word_game_agent.html#ad09d1aea570ee1284b1c46e3495b86f2',1,'Thinksquirrel.WordGameBuilder.Gameplay.WordGameAgent.processWildcards()'],['../class_thinksquirrel_1_1_word_game_builder_1_1_tiles_1_1_letter_tile_1_1_selection_info.html#ad09d1aea570ee1284b1c46e3495b86f2',1,'Thinksquirrel.WordGameBuilder.Tiles.LetterTile.SelectionInfo.processWildcards()']]]
];
