var searchData=
[
  ['colorinfo',['ColorInfo',['../class_thinksquirrel_1_1_word_game_builder_1_1_tiles_1_1_letter_tile_1_1_color_info.html',1,'Thinksquirrel::WordGameBuilder::Tiles::LetterTile']]]
];
