var searchData=
[
  ['previous_20releases',['Previous Releases',['../changelog_old.html',1,'changelog']]],
  ['performance_20considerations',['Performance Considerations',['../performance.html',1,'advanced']]]
];
