var searchData=
[
  ['maxprefixlength',['maxPrefixLength',['../class_thinksquirrel_1_1_word_game_builder_1_1_word_set.html#a5e8f20eb887262c7b3819b1ca0e22c83',1,'Thinksquirrel::WordGameBuilder::WordSet']]]
];
