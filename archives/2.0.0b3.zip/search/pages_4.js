var searchData=
[
  ['importing_20languages',['Importing Languages',['../importinglanguages.html',1,'guide']]],
  ['installation',['Installation',['../installation.html',1,'guide']]]
];
